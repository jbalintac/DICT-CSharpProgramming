﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// TODO: 5
namespace ConsoleDemo
{
    // TODO: 5
    class Class1
    {
    }
}
