﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleDemo.Model
{
    static class Helper
    {
        public static string MyGreatConverter(this Dog number)
        {
            return "";
        }
        public static string ConvertToInt()
        {
            return "";
        }
    }
}
